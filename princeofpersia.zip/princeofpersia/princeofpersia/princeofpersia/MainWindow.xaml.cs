﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace princeofpersia
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TvorbaMapy mapka;
        Hrac player;
        DispatcherTimer casovac;

        public MainWindow()
        {
            InitializeComponent();
            mapka = new TvorbaMapy(mriz);
            casovac = new DispatcherTimer(DispatcherPriority.Render);
            casovac.Interval = new TimeSpan(0, 0, 0 , 0, 75);
            casovac.Tick += cas;
            casovac.Start();
            player = new Hrac(mriz, mapka);
        }

        int x = 0;
        int y = 0;
        int pocetskoku = 0;
        bool pohyb = false;
        bool skace = false;
        bool skok = false;

        private void cas(object sender, EventArgs e)
        {
            if(pohyb)
            {
                player.pohyb(x, 0);
            }

            if (skok && pocetskoku < 2 )
            {
                skace = true;
                player.pohyb(0, y);
                pocetskoku++;
            }
            else
            {
                skok = false;
                skace = false;
                y = 0;
                player.upravGravitaci(1);
            }
        }

        private void klavesaup(object sender, KeyEventArgs e)
        {
            if(pohyb)
            {
                x = 0;
                pohyb = false;
            }
        }

        private void klavesadown(object sender, KeyEventArgs e)
        {
            switch(e.Key)
            {
                case Key.Left:
                    pohyb = true;
                    x = -30;
                    break;
                case Key.Right:
                    pohyb = true;
                    x = 30;
                    break;
                case Key.Space:
                    if(skace == false && Hrac.jeBlockPod)
                    {
                        player.upravGravitaci(0);
                        y = -30;
                        pocetskoku = 0;
                        skok = true;
                    }
                    break;
            }
        }
    }

    class TvorbaMapy
    {
        //43*20 - 1290 * 600
        static public char[,] mapa = new char[,] {
            { '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '.', 'Z', '#', '#', '#', '#', 'Z', '.', '.', '.', '#', '#', 'Z', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'F', '#', 'Z', '#', '#', 'Z', '#', 'F', '.', '.', 'F', '#', 'Z', '#', '#', 'Z', '.', '.', 'Z', 'V', 'V', 'Z', '#' },
            { '#', '.', '.', '.', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '#', '.', '.', '#', 'F', '#', '#', '#', 'F', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', 'F', '.', '.', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.', 'Z', 'F', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'F', '#', '#', '#', 'Z', '.', '.', 'F', '#', '#', 'Z', '#', '#', 'F', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'F', '.', '.', '.', '#' },
            { '#', '#', '#', '#', '#', 'Z', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#', 'F', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'F', '#', '#', 'Z', '#', 'F', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'F', '#', '.', '.', '#' },
            { '#', '.', '.', '.', '.', '.', '.', 'F', '#', 'Z', 'Z', '#', '.', '.', '.', '.', 'F', '#', '#', 'Z', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', 'F', '#', 'Z', '#', 'F', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', 'P', '.', '.', 'F', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', 'P', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#' },
            { '#', '#', '#', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', 'Z', '#' }
        };

        List<Image> seznamPropadavacich = new List<Image>();

        public TvorbaMapy(Grid mriz)
        {
            BitmapImage bricky = new BitmapImage();
            BitmapImage propadavaci = new BitmapImage();
            BitmapImage lebka = new BitmapImage();
            
            Image solid;
            Image propad;
            Image zabijeci;      

            bricky.BeginInit();
            bricky.UriSource = new Uri("https://i.imgur.com/dODE2ZB.png");
            bricky.EndInit();

            propadavaci.BeginInit();
            propadavaci.UriSource = new Uri("https://i.imgur.com/6xH3iyA.png");
            propadavaci.EndInit();

            lebka.BeginInit();
            lebka.UriSource = new Uri("https://i.imgur.com/GmkYkDQ.png");
            lebka.EndInit();

            for(int y = 0; y < 20; y++)
            {
                for(int x = 0; x < 43; x++)
                {
                    switch(mapa[y, x])
                    {
                        case '#':
                            solid = new Image();
                            solid.Source = bricky;
                            solid.Stretch = Stretch.None;
                            solid.VerticalAlignment = VerticalAlignment.Top;
                            solid.HorizontalAlignment = HorizontalAlignment.Left;
                            solid.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(solid);
                            break;
                        case 'F':
                            propad = new Image();
                            propad.Source = propadavaci;
                            propad.Stretch = Stretch.None;
                            propad.VerticalAlignment = VerticalAlignment.Top;
                            propad.HorizontalAlignment = HorizontalAlignment.Left;
                            propad.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            seznamPropadavacich.Add(propad);
                            mriz.Children.Add(propad);
                            break;
                        case 'Z':
                            zabijeci = new Image();
                            zabijeci.Source = lebka;
                            zabijeci.Stretch = Stretch.None;
                            zabijeci.VerticalAlignment = VerticalAlignment.Top;
                            zabijeci.HorizontalAlignment = HorizontalAlignment.Left;
                            zabijeci.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(zabijeci);
                            break;
                        case 'V':
                            solid = new Image();
                            solid.Source = bricky;
                            solid.Stretch = Stretch.None;
                            solid.VerticalAlignment = VerticalAlignment.Top;
                            solid.HorizontalAlignment = HorizontalAlignment.Left;
                            solid.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(solid);
                            break;
                       
                        default:
                            break;
                    }
                }
            }
        }

        public List<Image> posliList()
        {
            return seznamPropadavacich;
        }
    }

    class Hrac
    {
        static public bool jeBlockPod = false;
        int ubehladoba = 0;
        Image postavaa;
        DispatcherTimer casovac;
        Grid mrizg;
        TvorbaMapy mapkag;
        public Hrac(Grid mriz, TvorbaMapy mapka)
        {
            mrizg = mriz;
            mapkag = mapka;
            casovac = new DispatcherTimer(DispatcherPriority.Render);
            casovac.Tick += gravitace;
            casovac.Interval = new TimeSpan(0, 0, 0, 0, 100);
            BitmapImage postava = new BitmapImage();
            postava.BeginInit();
            postava.UriSource = new Uri("https://i.imgur.com/gDbB8P3.png");
            postava.EndInit();

            postavaa = new Image();
            postavaa.Source = postava;
            postavaa.Stretch = Stretch.None;
            postavaa.VerticalAlignment = VerticalAlignment.Top;
            postavaa.HorizontalAlignment = HorizontalAlignment.Left;
            postavaa.Margin = new Thickness(1 * 30, 17 * 30, 0, 0);
            mriz.Children.Add(postavaa);
        }

        private void gravitace(object sender, EventArgs e)
        {
            ubehladoba += 100;
            int xx = Convert.ToInt32(postavaa.Margin.Left);
            int yy = Convert.ToInt32(postavaa.Margin.Top);

            if(TvorbaMapy.mapa[yy/30 + 2, xx/30] == 'Z')
            {
                var mainWindow = (Application.Current.MainWindow as MainWindow);
                if (mainWindow != null)
                {
                    mainWindow.Close();
                }
                MessageBox.Show("Zemřel jsi! Zkus to znovu! :D ");
            }
            else if(TvorbaMapy.mapa[yy/30 + 2, xx/30] == 'V')
            {
                var mainWindow = (Application.Current.MainWindow as MainWindow);
                if (mainWindow != null)
                {
                    mainWindow.Close();
                }
                MessageBox.Show("Blahopřeji ti vyhrál jsi!");
            }
            else if((TvorbaMapy.mapa[yy/30 + 2, xx/30] == '#') || (TvorbaMapy.mapa[yy/30 + 2, xx/30] == 'F')) {jeBlockPod = true; } else {jeBlockPod = false; }

            if(jeBlockPod == false)
            {
                postavaa.Margin = new Thickness(xx, yy + 30, 0, 0);
            }
            if(TvorbaMapy.mapa[yy/30 + 2, xx/30] == 'F')
            {
                if(ubehladoba % 2000 == 0)
                {
                    try
                    {
                    List<Image> seznamProp = mapkag.posliList();
                    if(TvorbaMapy.mapa[yy/30 + 2, xx/30] == 'F')
                    {
                        foreach (Image obr in seznamProp)
                        {
                            if (obr.Margin.Top == postavaa.Margin.Top + 60)
                            {
                                seznamProp.Remove(obr);
                                mrizg.Children.Remove(obr);
                                TvorbaMapy.mapa[yy / 30 + 2, xx / 30] = '.';
                            }
                        }
                    }
                    ubehladoba = 0;
                    }
                    catch(Exception exc)
                    {
                        Debug.Print(Convert.ToString(exc));
                    }
                }
            }
            else if (ubehladoba % 2000 == 0)
            {
                ubehladoba = 0;
            }
        }

        public void pohyb(int x, int y)
        {
            int xx = Convert.ToInt32(postavaa.Margin.Left);
            int yy = Convert.ToInt32(postavaa.Margin.Top);

            bool jeBlockVlevo = false;
            bool jeBlockVpravo = false;

            if(TvorbaMapy.mapa[yy/30, xx/30 - 1] == '#' || TvorbaMapy.mapa[(yy/30) + 1, xx/30 - 1] == '#' ) {jeBlockVlevo = true; } else {jeBlockVlevo = false; }
            if(TvorbaMapy.mapa[yy/30, xx/30 + 1] == '#' || TvorbaMapy.mapa[(yy/30) + 1, xx/30 + 1] == '#' ) {jeBlockVpravo = true; } else {jeBlockVpravo = false; }
            if(TvorbaMapy.mapa[yy/30 + 2, xx/30] == '#') {jeBlockPod = true; } else {jeBlockPod = false; }

            if(y == 0)
            {
                if((x == -30 && jeBlockVlevo == false) || (x == 30 && jeBlockVpravo == false))
                {
                    postavaa.Margin = new Thickness(xx + x, yy, 0, 0);
                }
            }
            else
            {
                if(TvorbaMapy.mapa[yy/30 - 1, xx/30] != '#' && TvorbaMapy.mapa[yy/30 - 1, xx/30] != 'F')
                {
                    postavaa.Margin = new Thickness(xx, yy + y, 0, 0);
                }
            }
        }

        public void upravGravitaci(int co)
        {
            if(co == 0)
            {
                casovac.Stop();
            }
            if(co == 1)
            {
                casovac.Start();
            }
        }
    }
}