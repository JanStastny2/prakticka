﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO;

namespace princeofpersia
{
    /// <summary>64
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TvorbaMapy mapka;
        Hrac player;
        DispatcherTimer casovac;
        int level = 1;

        public MainWindow()
        {
            InitializeComponent();
            mapka = new TvorbaMapy(mriz,level);
            casovac = new DispatcherTimer(DispatcherPriority.Render);
            casovac.Interval = new TimeSpan(0, 0, 0 , 0, 75);
            casovac.Tick += cas;
            casovac.Start();
            player = new Hrac(mriz, mapka);
        }

        int x = 0;
        int y = 0;
        int pocetskoku = 0;
        bool pohyb = false;
        bool skace = false;
        bool skok = false;

        private void cas(object sender, EventArgs e)
        {
            if(pohyb)
            {
                player.pohyb(x, 0);
            }

            if (skok && pocetskoku < 2 )
            {
                skace = true;
                player.pohyb(0, y);
                pocetskoku++;
            }
            else
            {
                skok = false;
                skace = false;
                y = 0;
                player.upravGravitaci(1);
            }
            if (player.Positionleft >= 41)   //pokud se hráč dostane za blok 42, objevi se další level
            {
                level++;
                int pltop = player.Positiontop;
                mriz.Children.Clear();
                mapka = new TvorbaMapy(mriz, level);
                player = new Hrac(mriz, mapka);
                player.Positiontop = pltop;
            }
            if(player.Positionleft <= 0)  //pokud se hráč dostane za blok 0, objevi se předchozí level
            {
                level--;
                int pltop = player.Positiontop;
                mriz.Children.Clear();
                mapka = new TvorbaMapy(mriz, level);
                player = new Hrac(mriz, mapka);
                player.Positionleft = 40;
                player.Positiontop = pltop;

            }
        }

        private void klavesaup(object sender, KeyEventArgs e)
        {
            if(pohyb)
            {
                x = 0;
                pohyb = false;
            }
        }

        private void klavesadown(object sender, KeyEventArgs e)
        {
            switch(e.Key)
            {
                case Key.Left:
                    pohyb = true;
                    x = -30;
                    break;
                case Key.Right:
                    pohyb = true;
                    x = 30;
                    break;
                case Key.Space:
                    if(skace == false && player.BlockPod)
                    {
                        player.upravGravitaci(0);
                        y = -30;
                        pocetskoku = 0;
                        skok = true;
                    }
                    break;
            }
        }
    }

    class TvorbaMapy
    {
        //43*20 - 1290 * 600
    
        List<Image> seznamPropadavacich = new List<Image>();
        public Image[,] mapa = new Image[43,20];

        public List<Image> seznamMrizi = new List<Image>();

        public TvorbaMapy(Grid mriz, int level)
        {
            StreamReader cti = new StreamReader($"level{level}.txt"); //nacteni mapy ze souboru

            BitmapImage bricky = new BitmapImage();
            BitmapImage propadavaci = new BitmapImage();
            BitmapImage lebka = new BitmapImage();
            BitmapImage spike = new BitmapImage();
            BitmapImage naslapne = new BitmapImage();
            BitmapImage mrizeimg = new BitmapImage();
            BitmapImage vyhra = new BitmapImage();

            Image solid;
            Image propad;
            Image zabijeci;
            Image spiky;
            Image naslapny;
            Image mrize;
            Image vyhral;

            bricky.BeginInit();
            bricky.UriSource = new Uri("https://i.imgur.com/dODE2ZB.png");
            bricky.EndInit();

            propadavaci.BeginInit();
            propadavaci.UriSource = new Uri("https://i.imgur.com/6xH3iyA.png");
            propadavaci.EndInit();

            lebka.BeginInit();
            lebka.UriSource = new Uri("https://i.imgur.com/5ftxy1i.png");
            lebka.EndInit();

            spike.BeginInit();
            spike.UriSource = new Uri("https://i.imgur.com/XdHMRsa.png");
            spike.EndInit();
            
            naslapne.BeginInit();
            naslapne.UriSource = new Uri("https://i.imgur.com/6UMrykF.png");
            naslapne.EndInit();

            mrizeimg.BeginInit();
            mrizeimg.UriSource = new Uri("https://i.imgur.com/B8s4riQ.png");
            mrizeimg.EndInit();

            vyhra.BeginInit();
            vyhra.UriSource = new Uri("https://i.imgur.com/nd38LGy.png");
            vyhra.EndInit();

            for (int y = 0; y < 20; y++)
            {
                for(int x = 0; x < 43; x++)
                {
                    
                    switch(cti.Read())
                    {
                        case 35: //ASCI kod pro #
                            
                            solid = new Image();
                            solid.Name = "ohraniceni";
                            solid.Source = bricky;
                            solid.Stretch = Stretch.None;
                            solid.VerticalAlignment = VerticalAlignment.Top;
                            solid.HorizontalAlignment = HorizontalAlignment.Left;
                            solid.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(solid);
                            mapa[x, y] = solid;
                            break;
                        case 70: //ASCI kod pro F
                            propad = new Image();
                            propad.Name = "propadavaci";
                            propad.Source = propadavaci;
                            propad.Stretch = Stretch.None;
                            propad.VerticalAlignment = VerticalAlignment.Top;
                            propad.HorizontalAlignment = HorizontalAlignment.Left;
                            propad.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            seznamPropadavacich.Add(propad);
                            mriz.Children.Add(propad);
                            mapa[x, y] = propad;
                            break;
                        case 90: //ASCI kod pro Z
                            zabijeci = new Image();
                            zabijeci.Name = "zabijeci";
                            zabijeci.Source = lebka;
                            zabijeci.Stretch = Stretch.None;
                            zabijeci.VerticalAlignment = VerticalAlignment.Top;
                            zabijeci.HorizontalAlignment = HorizontalAlignment.Left;
                            zabijeci.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(zabijeci);
                            mapa[x, y] = zabijeci;
                            break;
                        case 83: //ASCI kod pro S
                            spiky = new Image();
                            spiky.Name = "spiky";
                            spiky.Source = spike;
                            spiky.Stretch = Stretch.None;
                            spiky.VerticalAlignment = VerticalAlignment.Top;
                            spiky.HorizontalAlignment = HorizontalAlignment.Left;
                            spiky.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(spiky);
                            mapa[x, y] = spiky;
                            break;
                        case 78: //ASCI kod pro N
                            naslapny = new Image();
                            naslapny.Name = "naslapny";
                            naslapny.Source = naslapne;
                            naslapny.Stretch = Stretch.None;
                            naslapny.VerticalAlignment = VerticalAlignment.Top;
                            naslapny.HorizontalAlignment = HorizontalAlignment.Left;
                            naslapny.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(naslapny);
                            mapa[x, y] = naslapny;
                            break;
                        case 77:  //ASCI kod pro M
                            mrize = new Image();
                            mrize.Name = "mrize";
                            mrize.Source = mrizeimg;
                            mrize.Stretch = Stretch.None;
                            mrize.VerticalAlignment = VerticalAlignment.Top;
                            mrize.HorizontalAlignment = HorizontalAlignment.Left;
                            mrize.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(mrize);
                            seznamMrizi.Add(mrize);
                            mapa[x, y] = mrize;
                            break;
                        case 86: //ASCI kod pro V
                            vyhral = new Image();
                            vyhral.Name = "vyhral";
                            vyhral.Source = vyhra;
                            vyhral.Stretch = Stretch.None;
                            vyhral.VerticalAlignment = VerticalAlignment.Top;
                            vyhral.HorizontalAlignment = HorizontalAlignment.Left;
                            vyhral.Margin = new Thickness(x * 30, y * 30, 0, 0);
                            mriz.Children.Add(vyhral);
                            mapa[x, y] = vyhral;
                            break;
                    }
                }
                cti.ReadLine();
            }
        }

        public List<Image> posliList()
        {
            return seznamPropadavacich;
        }
    }

    class Hrac
    {
        public bool BlockPod = false;
        int ubehladoba = 0;
        Image postavaa;
        DispatcherTimer casovac;
        Grid mrizg;
        TvorbaMapy mapkag;
        public Hrac(Grid mriz, TvorbaMapy mapka)
        {
            mrizg = mriz;
            mapkag = mapka;
            casovac = new DispatcherTimer(DispatcherPriority.Render);
            casovac.Tick += gravitace;
            casovac.Interval = new TimeSpan(0, 0, 0, 0, 100);
            BitmapImage postava = new BitmapImage();
            postava.BeginInit();
            postava.UriSource = new Uri("https://i.imgur.com/gDbB8P3.png");
            postava.EndInit();

            postavaa = new Image();
            postavaa.Source = postava;
            postavaa.Stretch = Stretch.None;
            postavaa.VerticalAlignment = VerticalAlignment.Top;
            postavaa.HorizontalAlignment = HorizontalAlignment.Left;
            postavaa.Margin = new Thickness(1 * 30, 17 * 30, 0, 0);
            mriz.Children.Add(postavaa);
        }
        public  int Positionleft
        {
            get
            {
              return Convert.ToInt32(postavaa.Margin.Left / 30); 
            }
            
            set 
            {
                postavaa.Margin = new Thickness(value * 30, postavaa.Margin.Top, 0, 0); 
            }
        }
        public int Positiontop
        {
            get
            {
                return Convert.ToInt32(postavaa.Margin.Top / 30);
            }

            set
            {
                postavaa.Margin = new Thickness(postavaa.Margin.Left, value * 30,  0, 0);
            }
        }

        private void gravitace(object sender, EventArgs e)
        {
            ubehladoba += 100;
            int x = Convert.ToInt32(postavaa.Margin.Left);
            int y = Convert.ToInt32(postavaa.Margin.Top);
            string nazev = null;
      
            if (mapkag.mapa[x / 30 , y / 30 + 2] !=null)
            {
                nazev = mapkag.mapa[x / 30 , y / 30 + 2].Name;
                BlockPod = true;
            }
            else if(y >= 17*30)
            {
                BlockPod = true;
            }

            else
            {
                BlockPod = false;
                nazev = null;
            }
            

            if(nazev == "zabijeci")
            {
                var mainWindow = (Application.Current.MainWindow as MainWindow);
                if (mainWindow != null)
                {
                    mainWindow.Close();

                }
                MessageBox.Show("Zemřel jsi! Zkus to znovu! :D ");
            }
            else if(nazev == "spiky")
            {
                var mainWindow = (Application.Current.MainWindow as MainWindow);
                if (mainWindow != null)
                {
                    mainWindow.Close();

                }
                MessageBox.Show("Zemřel jsi! Zkus to znovu! :D ");
            }
            else if(nazev == "naslapny")
            {
                foreach(Image img in mapkag.seznamMrizi)//projde Image v listu seznamMrizi a vymaže všechny obrázky, které v něm jsou a odstraní je na mapě
                {
                    mrizg.Children.Remove(img);
                    mapkag.mapa[Convert.ToInt32(img.Margin.Left)/30, Convert.ToInt32(img.Margin.Top) / 30] = null;
                }
            }
            else if(nazev == "vyhral")
            {
                var mainWindow = (Application.Current.MainWindow as MainWindow);
                if (mainWindow != null)
                {
                    mainWindow.Close();
                }
                MessageBox.Show("Blahopřeji ti vyhrál jsi!");
            }
            

            if(BlockPod == false)
            {
                postavaa.Margin = new Thickness(x, y + 30, 0, 0);
            }


            if(nazev == "propadavaci")
            {
                if(ubehladoba % 2000 == 0)
                {
                    try
                    {
                    List<Image> seznamProp = mapkag.posliList();
                    if(nazev == "propadavaci")
                    {
                        foreach (Image obr in seznamProp)
                        {
                            if (obr.Margin.Top == postavaa.Margin.Top + 60)
                            {
                                    mrizg.Children.Remove(obr);
                                    mapkag.mapa[Convert.ToInt32(obr.Margin.Left) / 30, Convert.ToInt32(obr.Margin.Top) / 30] = null;
                            }
                        }
                    }
                    ubehladoba = 0;
                    }
                    catch(Exception exc)
                    {
                        Debug.Print(Convert.ToString(exc));
                    }
                }
            }
            else if (ubehladoba % 2000 == 0)
            {
                ubehladoba = 0;
            }
        }

        public void pohyb(int x, int y)
        {
            int xx = Convert.ToInt32(postavaa.Margin.Left);
            int yy = Convert.ToInt32(postavaa.Margin.Top);
            
            bool kostkanalevo = false;
            bool kostkanapravo = false;

            if(mapkag.mapa[xx/30 - 1, yy/30 ] == null && mapkag.mapa[(xx/30) - 1, yy/30 + 1] == null ) {kostkanalevo = false; } else {kostkanalevo = true; }
            if(mapkag.mapa[xx/30 + 1, yy/30 ] == null && mapkag.mapa[(xx/30) + 1, yy/30 + 1] == null ) {kostkanapravo = false; } else {kostkanapravo = true; }
            if(mapkag.mapa[xx/30 + 2, yy/30 ] == null) {BlockPod = false; } else {BlockPod = true; }

            if(y == 0)
            {
                if((x == -30 && kostkanalevo == false) || (x == 30 && kostkanapravo == false))
                {
                    postavaa.Margin = new Thickness(xx + x, yy, 0, 0);
                }
            }
            else
            {
                if(mapkag.mapa[xx/30 , yy/30 - 1] == null)
                {
                    postavaa.Margin = new Thickness(xx, yy + y, 0, 0);
                }
            }
        }

        public void upravGravitaci(int co)
        {
            if(co == 0)
            {
                casovac.Stop();
            }
            if(co == 1)
            {
                casovac.Start();
            }
        }
    }
}