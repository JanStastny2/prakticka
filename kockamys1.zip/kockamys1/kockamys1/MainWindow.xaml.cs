﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace kockamys1
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>

    class kocka:zvire
    {
        public kocka():base(100, 100)
        {
            z.Fill = new SolidColorBrush(Colors.Brown);
        }

        internal void pohniSe(int x, int y)
        {
            if (z.Margin.Left + x >= 0 && z.Margin.Left + x <= 750 && z.Margin.Top + y >= 0 && z.Margin.Top + y <= 390)
            {
                int zleva = Convert.ToInt32(z.Margin.Left);
                int shora = Convert.ToInt32(z.Margin.Top);
                z.Margin = new Thickness(zleva + x, shora + y, 0, 0);
                //if (MainWindow.map.ctiMapu((shora + y) / 30, (zleva + x) / 30) is mys) (druhá možnost, nelze použít kvůli proměnné mice, která je vždy typu mys)
                mys mice = MainWindow.map.ctiMapu((shora + y) / 30, (zleva + x) / 30);

                if (mice != null)
                {
                    MainWindow.map.zmenMapu((shora + y) / 30, (zleva + x) / 30, null);
                    mice.chcipni();
                }
            }
        }
    }

    public class mys:hlodavec
    {
        public mys(int zleva, int shora)
        {
            m.Fill = new SolidColorBrush(Colors.Gray);
        }

        public void chcipni()
        {
            mriz.Children.Remove(m);
            pocetMysi--;
        }
    }

    public class mapa
    {
        mys[,] mapka = new mys[14, 26];
        public mapa()
        {

        }
        public void zmenMapu(int rada, int sloupec, mys m)
        {
            mapka[rada, sloupec] = m;
        }

        public mys ctiMapu(int rada, int sloupec)
        {
            return mapka[rada, sloupec];
        }
    }

    public partial class MainWindow : Window
    {
        List<mys> mysky = new List<mys>();
        kocka micka;
        Random nahoda = new Random();
        DispatcherTimer casovac = new DispatcherTimer(DispatcherPriority.Render);
        public static mapa map;

        int ts = 50;
        int interval = 0;

        public MainWindow()
        {
            InitializeComponent();
            mys.mriz = mriz;
            map = new mapa();

            casovac.Tick += budik;
            casovac.Interval = new TimeSpan(0, 0, 0, 0, ts);
            casovac.Start();
            zvire.mriz = mriz;
            micka = new kocka(); //voláme konstruktor třídy kočka
        }


        private void budik(object sender, EventArgs e)
        {
            if (pohyb)
            {
                micka.pohniSe(x, y);
            }
            interval++;
            if (interval == 1000 / ts)
            {
                SpawnutiMysi();
                interval = 0;
            }
        }

        private void SpawnutiMysi()
        {
            /*int zleva = nahoda.Next(26);
            int shora = nahoda.Next(14);
            mys mickey = new mys(mriz, zleva * 30 + 10, shora * 30 + 10);
            mickey.pocetMysi++;
            mysky.Add(mickey);
            map.zmenMapu(shora, zleva, mickey);
            if (mickey.pocetMysi == prohra)
            {
                casovac.Stop();
                MessageBox.Show("Prohrál jsi!");
            }
            */
            if (mys.pocetMysi < 10)
            {
                int zleva = nahoda.Next(25);
                int shora = nahoda.Next(13);
                mys mickey = new mys(zleva * 30 + 10, shora * 30 + 10);
                map.zmenMapu(shora, zleva, mickey);
            }
            else
            {
                casovac.Stop();
            }

        }
        int x = 0;
        int y = 0;
        bool pohyb = false;
        private void klavesaUp(object sender, KeyEventArgs e)
        {
            pohyb = false;
        }

        private void klavesaDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Left:
                    pohyb = true;
                    x = -30;
                    y = 0;
                    break;
                case Key.Right:
                    pohyb = true;
                    x = 30;
                    y = 0;
                    break;
                case Key.Up:
                    pohyb = true;
                    x = 0;
                    y = -30;
                    break;
                case Key.Down:
                    pohyb = true;
                    x = 0;
                    y = 30;
                    break;
            }
        }
    }
    class zvire
    {
        protected Rectangle z;
        public static Grid mriz;
        public zvire(int zleva, int shora)
        {
            z = new Rectangle();
            z.Width = 30;
            z.Height = 30;
            z.Fill = new SolidColorBrush(Colors.Brown);
            z.VerticalAlignment = VerticalAlignment.Top; //fix pohybu
            z.HorizontalAlignment = HorizontalAlignment.Left; // fix pohybu
            z.Margin = new Thickness(zleva , shora, 0, 0);
            mriz.Children.Add(z);
        }
    }
    


    class pes:zvire
    {
        public pes(int zleva, int shora): base(zleva, shora)
        {
            z.Fill = new SolidColorBrush(Colors.Blue);
        }
    }
}