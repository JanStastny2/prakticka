<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="cz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Slovní druhy</title>
    <script src="script.js" defer></script>
    <style>
         *{
            padding:0;
            margin: 0;
        }

        #vstup{
            width: 95vw; /*calc(100vw-10px)*/
            height: 12em;
            margin:10px;
            
        }
        .vybrano{
            border:red 5px solid;
        }
        #pjTab, #pjTab tr th, #pjTab tr td{
            border: 1px solid black;
            border-collapse: collapse;
        }
        #pjTab tr th{
            padding-left: 10px;
            padding-right: 10px;
            padding-bottom: 5px;
            padding-top: 5px;
        }
    </style>
</head>
<body>

    <div id="zadani">
        Sem vlož text:<br>
            <form method="POST">
                <textarea name="vstup"></textarea><br>
                <input type="submit" value ="Připrav"><br><br>
            </form>
    </div>
    
    <input type="button" value="Podstatná jména" style="background-color: aqua;padding:3px;" onclick="vyber(id);" id="i1" class = "vybrano"> 
    <input type="button" value="Přídavná jména" style="background-color:azure;padding:3px;"onclick="vyber(id);"id="i2"> 
    <input type="button" value="Zájmena" style="background-color:bisque;padding:3px;"onclick="vyber(id);"id="i3"> 
    <input type="button" value="Číslovky" style="background-color: darkkhaki;padding:3px;"onclick="vyber(id);"id="i4"> 
    <input type="button" value="Slovesa" style="background-color: gold;padding:3px;"onclick="vyber(id);"id="i5"> 
    <input type="button" value="Příslovce" style="background-color: lightcoral;padding:3px;"onclick="vyber(id);"id="i6"> 
    <input type="button" value="Předložky" style="background-color: orchid;padding:3px;"onclick="vyber(id);"id="i7"> 
    <input type="button" value="Spojka" style="background-color: yellowgreen;padding:3px;"onclick="vyber(id);"id="i8">  
    <input type="button" value="Částice" style="background-color: sandybrown;padding:3px;"onclick="vyber(id);"id="i9">
    <input type="button" value="Citoslovce" style="background-color: lightsalmon;padding:3px;"onclick="vyber(id);"id="i0">  
    <div id="slova">

        <?php
        if(isset($_POST["vstup"])){
            $text=explode(" ", $_POST["vstup"]);
            $_SESSION["slova"]=$text;
            foreach($text as $sl){  
        ?>
        <input type="button" class="i0" value=" <?php echo $sl ?> " onclick="nastav(this)">
        <?php
            }
        }
        ?>

    </div>
    <table>
        <tbody id="pjTab" style="display: none;">
        <tr>
            <th>Podstatné jméno</th>
            <th>Rod</th>
            <th>Číslo</th>
            <th>Pád</th>
            <th>Vzor</th>
        </tr>
        </tbody>
    </table>
    <br>
    <form method = "POST">
        <input type="submit" value="Ulož" name="tl1">
        <label name= "sl"></label>
        <label name= "dr"></label>
        <br>
    </form>
    <?php
        if(isset($_POST["tl1"])){
            $servername = "localhost";
            $username = "19ia25";
            $password = "sexymeda";
            $database = "19ia25";

            $conn = mysqli_connect($servername, $username, $password, $database);

            if(!$conn) {
                die("připojení selhalo: " . mysqli_connect_error());
            }
                echo "Úspěšně připojeno";
            $druhy=explode(",",$_POST["dr"]);
            $sl=$_SESSION['slova'];
            for ($i=0; $i < count($_SESSION['slova']).lenght; $i++) { 
                    
                }
            $sql = "INSERT INTO slova (slovo, druh, ID_zadani) VALUES ('$sl[$i]',$druhy[$i],1)";
            if(mysqli_query($conn, $sql)){
                echo " Úspěsně uloženo";
            }
            else{
                echo "Chyba",mysqli_error($conn);
            }
        }
    ?>
</body>
</html>