let vyb = "il";
//let reseni =[];
let vybBarva = document.getElementById(vyb).style.backgroundColor;
function vyber(id){
    document.getElementById(vyb).className = "";
    document.getElementById(id).className = "vybrano";

    vyb = id;
    vybBarva =  document.getElementById(vyb).style.backgroundColor;
}

function nastav(sender){
    sender.style.backgroundColor = vybBarva;
    sender.className=vyb;
    //reseni = [];
    var tlslova = document.getElementById("slova").getElementsByTagName("input")
    document.getElementsById("dr").vaule="";
    for (var i = 0; i < tlslova.length; i++) 
    {
        document.getElementsById("dr").value+=tlslova[i].className.substring(1)+",";
    }
  
}