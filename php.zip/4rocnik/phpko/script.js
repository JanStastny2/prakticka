let vyb ="i1";
let reseni=[];
let vybBarva = document.getElementById(vyb).style.backgroundColor;
function vyber(id)
{
    document.getElementById(vyb).className = "";
    document.getElementById(id).className="vybrano";
    
    vyb = id;
    vybBarva = document.getElementById(vyb).style.backgroundColor;
}
function nastav(sender)
{
    sender.style.backgroundColor = vybBarva;
    sender.className=vyb;
    reseni=[];
    var tlslova = document.getElementById("slova").getElementsByTagName("input");
    document.getElementsById("dr").innerHTML="";
    for (var i = 0; i < tlslova.length; i++) {
      
        reseni.push(tlslova[i].className.substring(1));
        document.getElementsById("dr").innerHTML+=reseni[i];
    }
   
}