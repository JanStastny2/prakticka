<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>  
    <form method="post">
    Vek: <input type="text" id=""><br>
    Vaha: <input type="text" id=""> <br>
    Vyska: <input type="text" id=""><br>
    Pohlaví: <input type="button" value="M"> <input type="button" value="Ž">
    </form>
    <?php

    ?>
    
</body>
</html>