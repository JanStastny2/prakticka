<?php
define('SQL_HOST','vocko');
define('SQL_DBNAME','19ia25');
define('SQL_USERNAME','19ia25');
define('SQL_PASSWORD','sexymeda');

function db_connect()
{
   $dsn = 'mysql:dbname=' . SQL_DBNAME . ';host=' . SQL_HOST . '';
   $user = SQL_USERNAME;
   $password = SQL_PASSWORD;

    try {
        $db = new PDO($dsn,$user,$password);
    } catch (PDOException $e) {
        print ("Něco se nepovedlo" . $e->getMessage());
    }
    return $db;
}
?>