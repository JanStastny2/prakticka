<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST">
    <label>Uživatelksé jméno</label><input type="text" name="username"><br>
    <label>Email</label><input type="text" name="email"><br>
    <label>Heslo</label><input type="password" name="password"><br>
    <input type="submit" name="login" value="přihlášení"><br>
    </form>
    <?php
        require_once 'config.php';
        $db = db_connect();

        if (isset($_POST["login"])) {
           $errorsMsg = [];
           $username = trim($_POST["username"]);
           $email = trim($_POST["email"]);
           $password = trim($_POST["password"]);

           if (empty($username)) 
            array_push($errorsMsg,"Zadej už. jméno");
           if (empty($email)) 
            array_push($errorsMsg,"Zadej email");
           if (empty($password)) 
            array_push($errorsMsg,"Zadej heslo");
             
               if (!empty($errorsMsg)) {
                   $text = "";
                   foreach($errorsMsg as $value)
                   {
                       $text = $text . $value . " ";
                   }
                   print($text);
                   $text = null;
                   $errorsMsg = null;
               }
            else {
                try {
                    $query = "SELECT username,email,password FROM masteri3a WHERE username = ? OR email=?";
                    $select_stm = $db->prepare($query);
                    $select_stm->execute(array(
                        $username,
                        $email
                    ));
                   // print_r($select_stm);
                   $row = $select_stm->fetchAll(PDO::FETCH_ASSOC);
                   //print_r($row);
                  //print_r($select_stm->rowCount());
                    
                  if ($select_stm->rowCount()>0) {
                      if (($username == $row[0]['username'])&&($email == $row[0]['email'])){
                          if (password_verify($password,$row[0]['password'])) {
                              $_SESSION["user_login"] = $row[0]['username'];
                              header("refresh:2;index.php");
                          }
                        }
                        else 
                            array_push($errorsMsg,"Špatné jméno nebo heslo");  
                   }
                  else 
                      array_push($errorsMsg,"uživatel není v db");
                  

                } catch (PDOException $e) {
                  print("Něco se nezdařilo" .$e->getMessage());
                }
            }
        }
  ?>  
</body>
</html>