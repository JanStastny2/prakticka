<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST">
    <label>Uživatelské jméno </label> <input type="text" name="username"> <br> 
    <label>Email</label> <input type="text" name="email"> <br> 
    <label>Heslo</label> <input type="password" name="password"> <br> 
    <label>Heslo znovu</label> <input type="password" name="password2"> <br> 
    <label>Role</label>
    <select name="role">
        <option value="" selected="Vyber roli">Vyber roli</option>
        <option value="employee">Zeměstnanec</option>
        <option value="user">Uživatel</option>
    </select>
    <br>
    <input type="submit" name="register" value="Registrace">
    <?php
        require_once 'config.php';
        $db = db_connect();

        if (isset($_POST["register"])) {
           $errorsMsg = [];
           $username = trim($_POST["username"]);
           $email = trim($_POST["email"]);
           $password = trim($_POST["password"]);
           $password2 = trim($_POST["password2"]);
           $role = trim($_POST["role"]);

           if (empty($username)) 
            array_push($errorsMsg,"Zadej už. jméno");
           if (empty($email)) 
            array_push($errorsMsg,"Zadej email");
           if (empty($password)) 
            array_push($errorsMsg,"Zadej heslo");
            if (empty($password2)) 
            array_push($errorsMsg,"Zadej znovu heslo");
           if (empty($role)) 
            array_push($errorsMsg,"Zadej roli");
           if (!filter_var($email, FILTER_VALIDATE_EMAIL))
               array_push($errorsMsg,"Zadej validní email");
            if ($password !=$password2)
               array_push($errorsMsg,"Zadaná hesla se neshodují");  
            if (strlen($password)<6)
               array_push($errorsMsg,"Heslo ma mene nez 6 znaku");  
             
               if (!empty($errorsMsg)) {
                   $text = "";
                   foreach($errorsMsg as $value)
                   {
                       $text = $text . $value . " ";
                   }
                   print($text);
                   $text = null;
                   $errorsMsg = null;
               }
               else {
                 try {
                     $select_stm = $db->prepare("SELECT username,email FROM masteri3a WHERE username = ? OR email = ?");
                     $select_stm->execute(array(
                                    $username,
                                    $email
                     ));
                     $row = $select_stm->fetchAll(PDO::FETCH_ASSOC);
                     $count = count($row);
                     if ($count >= 1) {
                         print'Uživatel nebo email existuje';
                     }
                     else {
                         $hash_encrypt = password_hash($password, PASSWORD_DEFAULT);
                         $insert_stm = $db->prepare("INSERT INTO masteri3a(username,email,password,role) VALUES(?,?,?,?)");

                         $insert_stm->execute(array(
                            $username,
                            $email,
                            $hash_encrypt,
                            $role
                         ));
                         print("Registrace proběhla úspěšně");
                         header("refresh:2;index.php");

                     }

                 } catch (PDOException $e) {
                     print("Něco se nepodařilo ".$e->getMessage());
                 }
               }
           
        }
    ?>
    </form>
</body>
</html>