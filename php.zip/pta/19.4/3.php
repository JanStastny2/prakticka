<?php
    session_start();
    if(empty($_SESSION['family']))
    {
        $_SESSION['family'] = array();

    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        <label for="fam">Jméno</label> <input type="text" id="fam" name="family"><br>
        <label for="num1">Plat </label> <input type="text" id="num1" name="moveIn">
        <br><input type="submit" name="btMoveIn" value="Přidat zaměstnance"><br>
       <br>
        <input type="submit" name="btVisitAll" value="Kdo má nejvyšší plat?">
    </form>   
    <?php


        

        function MoveIn($myFamily, $myMoveIn)
        {
            if(empty($_SESSION['family'][$myMoveIn]))
            {
                $_SESSION['family'][$myMoveIn] = $myFamily;
            }
            print "$myFamily";

        }

        function Visit($myVisit)
        {
            if(!empty($_SESSION['family'][$myVisit]))
            {
                $text = "V pokoji " . $myVisit . " je nastěhován: " . $_SESSION['family'][$myVisit];
                print
                '<script>
                    alert("'.$text.'");
                </script>';
            }
            else
                print
                '<script>
                    alert("V daném bytě nikdo není");
                </script>';                
        }

        function VisitAll()
        {
            $text ="";
            for($i = 0; $i < 2; $i++)
                if (!empty($_SESSION['family'][$i]))
                    $text = $text . "" . $i . " je nastěhován: " . $_SESSION['family'][$i] . "<br>";
                else
                    $text = $text . "V pokoji " . $i . " je nastěhován: Byt neobsazen" . "<br>";   
            print $text;     
        }

        if(isset($_POST["btMoveIn"]) && isset($_POST["family"]) && isset($_POST["moveIn"]))
        {
            MoveIn($_POST["family"], $_POST["moveIn"]);
            $_POST["btMoveIn"] = null;
            $_POST["family"] = null;
            $_POST["moveIn"] = null;
        }

        if(isset($_POST["btVisit"]) && isset($_POST["visit"]))
        {
            Visit($_POST["visit"]);
            $_POST["btVisit"] = null;
            $_POST["visit"] = null;
        }

        if(isset($_POST["btVisitAll"]))
        {
            VisitAll();
            $_POST["btVisitAll"] = null;
        }
    ?> 
</body>
</html>