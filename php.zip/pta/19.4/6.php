<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST">
   
        <label>Mocněnec</label>
        <input type="text" name="mocnitel">
        <br>
        <label>Mocnitel</label>
        <input type="text" name="mocnenec">
        <br>
        <br>
        <input type="submit" value="Spocti" name="bt">


    </form>   
    <?php

         function Pismeno($mocnitel, $mocnenec, $vysledek)
        {
            $mocnina = 1;
            for ($i=1;$i<=$mocnitel;$i++) { 
                $mocnina = $mocnenec*$mocnina;
            }
            print "$mocnina";
        }
        

        if (isset($_POST['bt'])) {
            Pismeno($_POST['mocnenec'],$_POST['mocnitel'],$_POST['vysledek']);
        }


    ?> 
</body>
</html>