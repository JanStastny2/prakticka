<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST">
       <label>Zadejte plnou cenu:</label> <input type="text" name="plna"> <br>
        <label>Vyberte slevu</label> <br>
        <input type="checkbox" name="detska">
        <label>Dítě/senior</label><br>
        <input type="checkbox" name="skupina">
        <label>Skupina</label><br>
        <input type="submit" value="Spočítat cenu" name="bt">

    </form>   
    <?php

    function Sleva($sleva)
    {
        $plna = $_POST['plna'];
        if ($_POST['detska']) {
           $plna = 
           print "$plna";
        }
    }

    // uvozovky vypisi hodnotu z promenne
    // apsotrof vypise doslovne co se v nich nachazi
    if (isset($_POST['bt'])) {
        Sleva($_POST['plna']);
    }

    ?> 
</body>
</html>