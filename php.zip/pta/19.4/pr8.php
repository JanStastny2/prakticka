<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        <label for="fam">Rodina</label> <input type="text" id="fam" name="family"><br>
        <label for="num1">Číslo bytu: </label> <input type="text" id="num1" name="moveIn"><input type="submit" name="btMoveIn" value="Nastěhovat"><br>
        <label for="num2">Číslo bytu: </label> <input type="text" id="num2" name="moveOut"><input type="submit" name="btMoveOut" value="Vystěhovat"><br>
        <label for="num3">Číslo bytu:</label> <input type="text" id="num3" name="visit"><input type="submit" name="btVisit" value="Zobrazit"><br>
        <input type="submit" name="btVisitAll" value="Zobrazit všechny">
    </form>   
    <?php
        $family = array(15);
        $family[0] = "Alšovi";
        $family[4] = "Novákovi";
        $family[7] = "Brázdilovi";
        $family[8] = "Brandorádorovi";
        $family[14] = "Novotní";

        function MoveOut($moveOut)
        {
            global $family;
            if(empty($family[$moveOut]))
                print
                    '<script>
                        alert("Byt je prázdný, není koho vystěhovat");
                    </script>';
            else
            {
                    $family[$moveOut] = null;
                    print
                    '<script>
                        alert("Úspěšně vystěhováno");
                    </script>';

            }

        }

        function MoveIn($myFamily, $myMoveIn)
        {
            global $family;
            if(empty($family[$myMoveIn]))
            {
                $family[$myMoveIn] = $myFamily;
                print
                    '<script>
                        alert("Úspěšně nastěhováno");
                    </script>';
            }
            else
                print
                    '<script>
                        alert("Byt je plný, nelze nastěhovat");
                    </script>';

        }

        function Visit($myVisit)
        {
            global $family;
            if(!empty($family[$myVisit]))
            {
                $text = "V pokoji " . $myVisit . " je nastěhován: " . $family[$myVisit];
                print
                '<script>
                    alert("'.$text.'");
                </script>';
            }
            else
                print
                '<script>
                    alert("V daném bytě nikdo není");
                </script>';                
        }

        function VisitAll()
        {
            global $family;
            $text ="";
            for($i = 0; $i < 15; $i++)
                if (!empty($family[$i]))
                    $text = $text . "V pokoji " . $i . " je nastěhován: " . $family[$i] . "<br>";
                else
                    $text = $text . "V pokoji " . $i . " je nastěhován: Byt neobsazen" . "<br>";   
            print $text;     
        }

        if(isset($_POST["btMoveIn"]) && isset($_POST["family"]) && isset($_POST["moveIn"]))
        {
            MoveIn($_POST["family"], $_POST["moveIn"]);
            $_POST["btMoveIn"] = null;
            $_POST["family"] = null;
            $_POST["moveIn"] = null;
        }

        if(isset($_POST["btMoveOut"]) && isset($_POST["moveOut"]))
        {
            MoveOut($_POST["moveOut"]);
            $_POST["btMoveOut"] = null;
            $_POST["moveOut"] = null;
        }

        if(isset($_POST["btVisit"]) && isset($_POST["visit"]))
        {
            Visit($_POST["visit"]);
            $_POST["btVisit"] = null;
            $_POST["visit"] = null;
        }

        if(isset($_POST["btVisitAll"]))
        {
            VisitAll();
            $_POST["btVisitAll"] = null;
        }
    ?> 
</body>
</html>