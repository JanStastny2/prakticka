function Disabled(id)
{
    document.getElementById(id).disabled = true;
}

function Enabled(id)
{
    document.getElementById(id).disabled = false;
}