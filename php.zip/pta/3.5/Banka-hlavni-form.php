<?php   
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="script.js"></script>
</head>
<body>
<form method="GET">
		<input type="text" id="uzivatel" name="uzivatel" placeholder="Uživatelské jméno">
		<input type="text" id="ucetUzivatel" name="ucetUzivatel" placeholder="Částka na účtu">
		<br>
		<input type="submit" id="ucet" name="ucet" value="Vytvoř účet">
		<input type="submit" id="rUcet" name="rUcet" value="Resetuj účet" disabled>	
		<br>
		<input type="number" id="castka" name="castka" placeholder="Částka" disabled>
		<br>
		<input type="checkbox" id="checked1" name="checked1" value="0" disabled> Vložit
		<input type="checkbox" id="checked2" name="checked2" value="0" disabled> Vybrat
		<br>
		<input type="submit" id="zpracuj" name="zpracuj" value="Zpracuj" disabled>
		<input type="submit" id="zobraz" name="zobraz" value="Zobraz" disabled>		
	</form>
    <?php
        require_once 'Bank.php';
        if(isset($_GET["uzivatel"]) && isset($_GET["ucetUzivatel"]) && isset($_GET["ucet"]))
        {
            $osobni = new Banka($_GET["ucetUzivatel"],$_GET["uzivatel"]);
            $_SESSION['osobni'] = serialize($osobni);
            print'
                <script>
                Disabled("uzivatel");
                Disabled("ucetUzivatel");
                Disabled("ucet");
                Enabled("rUcet");
                Enabled("castka");
                Enabled("checked1");
                Enabled("checked2");
                Enabled("zpracuj");
                Enabled("zobraz");
                </script>
            ';
        }
        if(isset($_GET["zpracuj"]))
        {
            print'
                <script>
                Disabled("uzivatel");
                Disabled("ucetUzivatel");
                Disabled("ucet");
                Enabled("rUcet");
                Enabled("castka");
                Enabled("checked1");
                Enabled("checked2");
                Enabled("zpracuj");
                Enabled("zobraz");
                </script>
            ';
            
            if(isset($_GET["checked1"]) && isset($_GET["castka"])){
                $osobni = unserialize($_SESSION['osobni']);
                $osobni->Vloz($_GET["castka"]);
                $_SESSION['osobni'] = serialize($osobni);
            }
            

            if(isset($_GET["checked2"]) && isset($_GET["castka"])) 
            {
                $osobni = unserialize($_SESSION['osobni']);
                $vyber =  $osobni->Vyber($_GET["castka"]);
                if($vyber == 0)
                    print 'Nemáte prašulky, tak nemůžete nic vybrat';
                else
                    print 'Úspěšně vybráno';
                    $_SESSION['osobni'] = serialize($osobni);
            }   
        }

        if(isset($_GET["zobraz"]))
        {
            print'
                <script>
                    Disabled("uzivatel");
                    Disabled("ucetUzivatel");
                    Disabled("ucet");
                    Enabled("rUcet");
                    Enabled("castka");
                    Enabled("checked1");
                    Enabled("checked2");
                    Enabled("zpracuj");
                    Enabled("zobraz");
                </script>
            ';
            $osobni = unserialize($_SESSION['osobni']);
            print  $osobni->Zobraz();
        }

    ?>    
</body>
</html>