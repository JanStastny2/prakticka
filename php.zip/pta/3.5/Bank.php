<?php
    class Banka
    {
        private $ucet;
        private $vlastnik;

        public function __construct($ucet,$vlastnik)
        {
            $this->ucet = $ucet;
            $this->vlastnik = $vlastnik;
        }

        public function Vloz($castka)
        {
            $this->ucet = $this->ucet + $castka; 
        }

        public function Vyber($castka)
        {
            if ($castka >  $this->ucet)
                return 0;
            else
            {
                $this->ucet = $this->ucet - $castka;
                return 1;
            }    
        }

        public function Zobraz()
        {
            $text = "";
            $text = "Na účtu $this->vlastnik máte uloženou částku: $this->ucet";
            return $text;
        }
    }
?>