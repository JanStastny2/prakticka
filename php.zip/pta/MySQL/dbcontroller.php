<?php
    class DBController
    {
        private $host = "vocko";
        private $user = "korineko";
        private $password = "sexymeda";
        private $database = "korineko";
        private $conn;

    public function __construct()
    {
        $this->conn =$this->ConnectDB();
    }    

    public function ConnectDB()
    {
        $dsn = 'mysql:dbname=' . $this->database . ';host=' . $this->host .'';
        $user = $this->user;
        $password = $this->password;
        
        try
        {
            $conn = new PDO($dsn,$user,$password);  
            $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            if($conn) 
             print "Úspěšně připojeno"."<br>";
        }
        catch(PDOException $e)
        {
            print ("Něco se nezdařilo ".$e->getMessage());
        }

        return $conn; 
    }

    public function SelectWrong($table,$column)
    {
        $stmt = $this->conn->query("SELECT * FROM $table");

        while($row = $stmt->fetch())
        {
            print $row["$column"]."<br>";
        }
    }

    public function InsertWrong($table)
    {
        $this->conn->query("INSERT INTO $table VALUES(3,'Petr','Petr');DROP TABLE i3apta2");
    }

    }
   
?>