<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST">
    <label for="table">Zadej jméno tabulky</label><input type="text" name="table" id="table"><br>
    <label for="column">Zadej jméno sloupce</label><input type="text" name="column" id="column"><br>
    <input type="submit" name="button" value="Vypiš">
    <input type="submit" name="button2" value="Vlož chybně" >
    </form>

    <?php
    require_once 'dbcontroller.php';
    $select = new DBController();

    if (isset($_POST["table"])) {
        $select->SelectWrong($_POST["table"],$_POST["column"]);
        $_POST["table"]=null;
        $_POST["column"]=null;
        $_POST["button"]=null;
    }

    if (isset($_POST["table"])&& isset($_POST["button2"])) {
        $select->InsertWrong($_POST["table"]);
        $_POST["table"]=null;
        $_POST["button2"]=null;
    }
    ?>
</body>
</html>