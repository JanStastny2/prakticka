<?php
    class Banka
    {
        private $ucet;
        private $zustatek;

        public function __constructor($ucet, $zustatek)
        {
             $this->ucet = $ucet;
            $zustatek->zustatek = $zustatek;
        }

        public function Vlozit($castka)
        {
            $this->zustatek = $this->zustatek + $castka;
        }

        public function Vyber($castka)
        {
            if ($castka > $this->zustatek) {
                return 0;
            }
            else
            {
                $this->zustatek = $this->zustatek -$castka;
                return 1;
            }
        }

        public function Zobraz()
        {
            $text = "Na účtu $this->ucet mate zustatek $this->zustatek";
            return $text;
        }
    }
?>