<?php
    require_once 'Bank.php';
    $osobni = new Banka("Muj",100000);
    print $osobni->Zobraz();
    print '<br>';
    $osobni->Vlozit(100000);
    print ($osobni->Zobraz());
    print '<br>';
    $vyber = $osobni->Vyber(250000);
    if ($vyber ==0) {
        print 'Nemáš prašulky, nemuzes vybrat tolik';
    }
    else   
    print 'Upesne vybrano, na uctu mas zustatek'.$osobni->Zobraz();
?>