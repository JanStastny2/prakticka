<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<p style="font-size: 30px;">Úloha 1</p>
    <form method="post">
        a<input type="number" name="a">*x2+b<input type="number" name="b">*x+c<input type="number" name="c">=0
        <br><input type="submit" value="vypocitat diskriminant" name="bt1">
    </form>
    <?php
        if (isset($_POST['bt1'])) {
            $a = $_POST['a'];
            $b = $_POST['b'];
            $c = $_POST['c'];
        }
        $x = $b*$b - (4*$a*$c);
       if ($x==0) {
       $x = -$b / (2*$a);
       echo "rovnice ma 1 kořen a tím je: ".$x;
       }
       else if ($x<0) {
        echo "diskriminant je zaporny";
       }
       else {
        $x1 = -$b+sqrt($x) / (2*$a);
        $x2 = (-$b)-(sqrt($x)) / ($a*2);
        echo "rovnice má 2 kořeny, těmi jsou x1: ".$x1." a x2: ".$x2;
       }
    ?>

    <p style="font-size: 30px;">Úloha 2</p>
    <form method="post">
        Zadejte nazev tabulky <input type="text" name="table_name"><br>
        <input type="text" name="nazev1"><select name="typ1">
            <option value="int">int</option>
            <option value="varchar(50)">varchar</option>
            <option value="date">date</option>
        </select>
        <select name="null1">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select>
        Ma byt autoincrement?
        <select name="inc1">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT PRIMARY KEY">Ano</option>
        </select><br>
        <input type="text" name="nazev2"><select name="typ2">
            <option value="int">int</option>
            <option value="varchar(50)">varchar</option>
            <option value="date">date</option>
        </select>
        <select name="null2">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select>
        Ma byt autoincrement?
        <select name="inc2">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT PRIMARY KEY">Ano</option>
        </select><br>
        <input type="text" name="nazev3"><select name="typ3">
            <option value="int">int</option>
            <option value="varchar(50)">varchar</option>
            <option value="date">date</option>
        </select>
        <select name="null3">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select>
        Ma byt autoincrement?
        <select name="inc3">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT PRIMARY KEY">Ano</option>
        </select><br>
        <input type="text" name="nazev4"><select name="typ4">
            <option value="int">int</option>
            <option value="varchar(50)">varchar</option>
            <option value="date">date</option>
        </select>
        <select name="null4">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select>
        Ma byt autoincrement?
        <select name="inc4">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT PRIMARY KEY">Ano</option>
        </select><br>
        <input type="submit" name="bt2">
    </form>
    <?php
        $servername = "localhost";
        $username = "19ia25";
        $password = "sexymeda";
        $dbname = "19ia25";
        $conn = new mysqli($servername, $username, $password,$dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
          }
          echo "Connected successfully";

    
     if ((isset($_POST['bt2']))) {
        $table_name = $_POST['table_name'];
        $nazev1 = $_POST['nazev1'];
        $typ1 = $_POST['typ1'];
        $null1 = $_POST['null1'];
        $inc1 = $_POST['inc1'];
    
        $nazev2 = $_POST['nazev2'];
        $typ2 = $_POST['typ2'];
        $null2 = $_POST['null2'];
        $inc2 = $_POST['inc2'];
        
        $nazev3 = $_POST['nazev3'];
        $typ3 = $_POST['typ3'];
        $null3 = $_POST['null3'];
        $inc3 = $_POST['inc3'];
       
        $nazev4 = $_POST['nazev4'];
        $typ4 = $_POST['typ4'];
        $null4 = $_POST['null4'];
        $inc4 = $_POST['inc4'];
     }
     if (!empty($table_name) && !empty($nazev1)&& !empty($nazev2)&& !empty($nazev3)&& !empty($nazev4)) {
        $sql = "CREATE TABLE IF not exists ".$table_name.
        " ( ".$nazev1." ".$typ1." ".$inc1." ".$null1.", ".
        $nazev2." ".$typ2." ".$inc2." ".$null2.", ".
        $nazev3." ".$typ3." ".$inc3." ".$null3.", ".
        $nazev4." ".$typ4." ".$inc4." ".$null4.");";
     }
     else {
       echo "Zadejte nazev tabulky i nazvy atributu";
     }

     if ($conn->query($sql) === TRUE) {
        echo "Table created successfully";
      } else {
        echo "Error creating table: " . $conn->error;
      }   
   
      ?>
    <p style="font-size: 30px;">Úloha 3</p>
      <FORM method="POST">
        id_kontaktu<input type="text" name="hodnota0"><br>
        Jmeno<input type="text" name="hodnota1"><br>
        Prijmeni<input type="text" name="hodnota2"><br>
        Ulice<input type="text" name="hodnota3"><br>
        CP<input type="text" name="hodnota4"><br>
        Mesto<input type="text" name="hodnota5"><br>
        id_psc<input type="text" name="hodnota6"><br>
        telefon<input type="text" name="hodnota7"><br>
        email<input type="text" name="hodnota8"><br>
        id_skupiny<input type="text" name="hodnota9">
        <input type="submit" name="bt3">
        

      </FORM>
    <?PHP
    
      if ((isset($_POST['bt3']))) {
        $jm = $_POST['hodnota1'];
        $pr = $_POST['hodnota2'];
        $ulice = $_POST['hodnota3'];
        $cp = $_POST['hodnota4'];
        $mesto = $_POST['hodnota5'];
        $psc = $_POST['hodnota6'];
        $telefon = $_POST['hodnota7'];
        $email = $_POST['hodnota8'];
        $id_s = $_POST['hodnota9'];
     }
    $sql = "INSERT INTO".$table_name." (jmeno ,prijmeni ,ulice ,CP ,mesto ,ID_PSC ,telefon ,email ,ID_skupiny) Values('".$jm."' ,"."'".$pr."' ,"."'".$ulice."' ,"."'".$cp."' ,"."'".$mesto."' ,"."'".$psc."' ,"."'".$telefon."' ,"."'".$email."' ,"."'".$id_s."')";

    if ($conn->query($sql) === TRUE) {
        echo "Success";
      } else {
        echo "Error insert into" . $conn->error;
      }   
    mysqli_close($conn);
    ?>

</body>
</html>