<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p style="font-size: 30px;" >Úloha 1</p>
<form method="POST">
   a<input type="text" name="a">
   b<input type="text" name="b">
   c<input type="text" name="c"><br>
   <input type="submit" value="Odeslat" name="bt"><br><br><br>
   </form>
   <?php 
        if(isset($_POST['bt'])){
            $a = $_POST['a'];
            $b = $_POST['b'];
            $c = $_POST['c'];
        }
        $vysledek = $b*$b-(4*$a*$c);
        if ($vysledek>0) { 
            $vysledek = sqrt($vysledek);
            $vysledek1 = (-$b+$vysledek)/(2*$a);
            $vysledek2 = (-$b-$vysledek)/(2*$a);
            if ($vysledek1==$vysledek2) {
                echo "rovnice má 2 stejné kořeny, jímž je: ".$vysledek1;
            }
            else echo "rovnice má 2 kořeny a těmi jsou: ".$vysledek1." a ".$vysledek2;
        }
        else if($vysledek==0){
            $vysledek = (-$b)/(2*$a);
            echo "rovnice má pouze jeden kořen a tím je: ".$vysledek;
        }
        else{ 
            echo "diskriminant je zaporny";
        }

       
 


      
            
        
        
    ?>
    <p style="font-size: 30px;">Úloha 2</p>
    <form method="post">
        Zadejte název tabulky <input type="text" name="table_name1"><br>
        Zadejte nazev atributu <input type="text" name="nazev1"><input type="text" name="nazev2"><input type="text" name="nazev3"><input type="text" name="nazev4"><br>
        Vyber datový typ <select name="typ1">
            <option value="varchar">varchar</option>
            <option value="int">int</option>
        </select>
        <select name="typ2">
            <option value="varchar">varchar</option>
            <option value="int">int</option>
        </select>
        <select name="typ3">
            <option value="varchar">varchar</option>
            <option value="int">int</option>
        </select>
        <select name="typ4">
            <option value="varchar">varchar</option>
            <option value="int">int</option>
        </select>

        <br>
        Má být NULL? <select name="null1">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select>
        <select name="null2">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select>
        <select name="null3">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select>
        <select name="null4">
        <option value="NOT NULL">NOT NULL</option>
            <option value="">NULL</option>
        </select><br>
        Má být Autoincrement? <select name="inc1">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT">Ano</option>
        </select> <select name="inc2">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT">Ano</option>
        </select>
        <select name="inc3">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT">Ano</option>
        </select>
        <select name="inc4">
            <option value="">Ne</option>
            <option value="UNSIGNED AUTO_INCREMENT">Ano</option>
        </select><br><br>
        <input type="submit" name="bt1" value="Vytvoř tabulku"><br>
    </form>

    <?php
  
        $servername = "localhost";
        $username = "19ia25";
        $password = "sexymeda";
        $servername = "localhost";
$username = "19ia25";
$password = "sexymeda";
// $dbname = "19ia25";

        if ((isset($_POST['bt1']))) {
            $table_name1 = $_POST['table_name'];
            $nazev1 = $_POST['nazev'];
            $typ1 = $_POST['typ'];
            $null1 = $_POST['null'];
            $inc1 = $_POST['inc'];
            $table_name2 = $_POST['table_name'];
            $nazev2 = $_POST['nazev'];
            $typ2 = $_POST['typ'];
            $null2 = $_POST['null'];
            $inc2 = $_POST['inc'];
            $table_name3 = $_POST['table_name'];
            $nazev3 = $_POST['nazev'];
            $typ3 = $_POST['typ'];
            $null3 = $_POST['null'];
            $inc3 = $_POST['inc'];
            $table_name4 = $_POST['table_name'];
            $nazev4 = $_POST['nazev'];
            $typ4 = $_POST['typ'];
            $null4 = $_POST['null'];
            $inc4 = $_POST['inc'];
        }
    
        //$conn = new mysqli($servername, $username, $password);

        if (!empty($table_name1) && !empty($nazev1)) {
            $
            $sql = "CREATE TABLE ".$table_name1." (".$nazev1." ".$typ1." ".$inc1." ". $null1;   
        }
        else {
            echo 'Zadejte název tabulky i název atributu!';
        } 
        

    ?>

</body>
</html>