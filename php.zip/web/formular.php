    <form method="post">
    <div id="menu">
        <p>Moje poznámky</p>
    <br>
    <input type="submit" value="Vytvořit poznámku" name="bt1">
        <br>
        </div> 
        <div id="vytvorit">
           <input type="text" name="name" placeholder="Název"><br>
            <input type="textarea" name="txt" placeholder="Poznámka..">
            <input type="date" name="date">   
        </div>
        
        <div id="odstranit">  


        </div>
        <input type="submit" value="X" name="bt2">
    </form>

    <?php
    // http://vocko/19ia25_stastny/web/formular.php?id=
//napul vyskakvaci okno nebo tak neco pomoci toho get 

        $conn = new mysqli("localhost", "19ia25", "sexymeda", "19ia25"); 
        if (isset($_POST['bt1'])) {
            echo '<script>window.location.replace("http://vocko/19ia25_stastny/web/formular.php?idk=nova_poznamka");</script>';
        }
        if (isset($_POST['bt2'])) {
            echo '<script>window.location.replace("http://vocko/19ia25_stastny/web/index.php?");</script>';
            //<script>document.getElementById("nova").id = "nova1"</script>';             
        }

        $name = $_POST['name'];
        $txt = $_POST['txt'];
        $date = $_POST['date'];
        if ($name != "") {
            $sql = "INSERT INTO Ukoly (Nazev, Poznamka, Datum)
            VALUES('$name', '$txt', '$date')";

            if (mysqli_query($conn, $sql)) {
                echo "Nový záznam byl úspěšně vložen.". "<br>";
            } else {
                echo "Chyba: " . $sql . "<br>" . mysqli_error($conn);
            } 
        }
        else 
            echo "Chyba " ."<br>";

        $sql1 = "SELECT * FROM `ukoly`";
        $result = $conn->query($sql1);
        $id = $_GET["id"];
        $sql2 = "SELECT Nazev, Poznamka, Datum FROM `ukoly` WHERE id=".$id;






        if ($id != "") {
            $res = $conn->query($sql2);
            $rad=mysqli_fetch_assoc($res); 
            $nazev = $rad["Nazev"];
            $poznamka = $rad["Poznamka"];
            $datum = $rad["Datum"];
        }
        

        if(mysqli_num_rows($result)>0){
            //echo "Výsledek má ".mysqli_num_rows($result). " řádků"."<br>";
            for ($i=0; $i < mysqli_num_rows($result); $i++) { 
                $radek=mysqli_fetch_assoc($result); 
               // print_r($radek);      //fetch vytvori asociativni pole - 
                $a = $i+1;                                         //k prvkum muzu prestupovat ne podle indexu ale i podle jmena
                echo $a.".".'<a href="http://vocko/19ia25_stastny/web/formular.php?id='.$radek["Id"].'">'.$radek["Poznamka"].'</a>'."<br>";
            }
        }    

    ?>

