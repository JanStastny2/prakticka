<div id="login">
    <p>Přihlášení k databázi</p>
    <form method="POST" id="login">
    <input type="submit" value="Přihlášení k db" name="bt0"><br><br>
        <a>login: </a><input type="text" name="login"><br>
        <a>password: </a> <input type="password" name="pass"><br><br>
        <input type="submit" value="Login" name="bt">

    </form>

    <?php


        $page = $_GET["page"];
        if ($page == "login") {
            include "login.php";
        }
        elseif ($page == "poznamky") {
            include "formular.php";
        }

            if (isset($_POST['bt0'])) {
                echo '<script>window.location.replace("http://vocko/19ia25_stastny/web/index.php?page=login");</script>';
                //header("Location: login.php");
            }

        if (isset($_POST['bt'])) {
            $login = $_POST['login'];
            $pass = $_POST['pass'];
            $conn = new mysqli("localhost", $login, $pass, $login);
            if ($conn->connect_error) {
                die("Connection failed"); 
            }
            else {
                echo "Connected succesfully";
              //  echo '<script>document.getElementById("login").id = "login1";</script>';
                //header("Location: formular.php");
                echo '<script>window.location.replace("http://vocko/19ia25_stastny/web/index.php?page=poznamky");</script>';

            }
        }  
    ?>
</div>

