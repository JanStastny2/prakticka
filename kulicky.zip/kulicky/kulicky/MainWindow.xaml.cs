﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace kulicky

{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    ///
    abstract class kulicka
    {
        protected Ellipse kul;
        public double PositionX
        {
            get
            {
                return kul.Margin.Left;
            }
        }
        public double PositionY
        {
            get
            {
                return kul.Margin.Top;
            }
        }
        abstract public void Move(double x, double y, int s);
    }
    class Player : kulicka
    {


        public Player(Ellipse hrac)
        {
            kul = hrac;
        }

        public override void Move(double x, double y, int s)
        {
            kul.Margin = new Thickness(PositionX + x, PositionY + y, 0, 0);
        }
    }

    class Bot : kulicka
    {

        Color bColor;
        double speed;
        bool crash = false;
        public int pchnk = 200;
        public bool Crash
        {
            get
            {
                return crash;
            }
            set
            {
                crash = value;
                if (crash)
                {
                    pchnk = 200;
                }
            }
        }
        public Bot(Grid mriz, int left, int top, int type)
        {
            //rozhodování typu nepřítele
            switch (type)
            {
                case 1:
                    bColor = Colors.Blue;
                    speed = 3;
                    break;
                case 2:
                    bColor = Colors.Green;
                    speed = 2;
                    break;
                case 3:
                    bColor = Colors.Gray;
                    speed = 0.5;
                    break;
                default:
                    bColor = Colors.Black;
                    speed = 1;
                    break;
            }

            //vytváření ellipsy nepřítele
            kul = new Ellipse()
            {
                Width = 30,
                Height = 30,
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Left,
                Fill = new SolidColorBrush(bColor),
                Margin = new Thickness(left, top, 0, 0)
            };
            mriz.Children.Add(kul);
        }

        public override void Move(double x, double y, int s)
        {
            double distanceX = s * (x - kul.Margin.Left); //vzdálenost po osy X mezi hráčem a botem
            double distanceY = s * (y - kul.Margin.Top); //vzdálenost po osy Y mezi hráčem a botem
            double d = Math.Sqrt(Math.Pow(distanceX, 2) + Math.Pow(distanceY, 2)); //dráha kterou má bot urazit
            double k = speed / d; //výpočet o kolik px se má bot bohnout po dráze
            double botMoveX = distanceX * k;
            double botMoveY = distanceY * k;

            kul.Margin = new Thickness(kul.Margin.Left + botMoveX, kul.Margin.Top + botMoveY, 0, 0);
        }
        public void zmiz(Grid mriz)
        {
            mriz.Children.Remove(kul);
        }
    }

 
    
    
    public partial class MainWindow : Window
    {
        Random nahoda = new Random();
        Player pl;
        List<Bot> enemies = new List<Bot>();

        double up = 0;
        double left = 0;
        int playerSpeed = 2;

        public MainWindow()
        {
            InitializeComponent();
            pl = new Player(hracEllipse);

            //vytváření nepřátel
            for (int i = 0; i < 8; i++)
            {
                Bot bot1 = new Bot(mriz, nahoda.Next(Convert.ToInt32(arena.Margin.Left), Convert.ToInt32(arena.Margin.Left + arena.Width - 30)), nahoda.Next(Convert.ToInt32(arena.Margin.Top), Convert.ToInt32(arena.Margin.Top + arena.Height - 30)), nahoda.Next(1, 4));
                enemies.Add(bot1);
            }

            //časovač
            DispatcherTimer cas = new DispatcherTimer();
            cas.Tick += timerTick;
            cas.Interval = new TimeSpan(0, 0, 0, 0, 5);
            cas.Start();
        }


        private void timerTick(object sender, EventArgs e)
        {
            pl.Move(left, up, 1);

            //pohyb nepřátelů
            for (int i = 0; i < enemies.Count; i++)
            {
                enemies[i].Crash = ((30 * 30 >= (pl.PositionY - enemies[i].PositionY) * (pl.PositionY - enemies[i].PositionY) + (pl.PositionX - enemies[i].PositionX) * (pl.PositionX - enemies[i].PositionX)));
                if (!enemies[i].Crash && enemies[i].pchnk == 0)
                {
                    enemies[i].Move(pl.PositionX, pl.PositionY, 1);
                }
                else
                {
                    enemies[i].Move(pl.PositionX, pl.PositionY, -1);
                    enemies[i].pchnk--;
                }
                for (int j = 1+1; j < enemies.Count; j++)
                {
                    if (15 * 15 >= (enemies[j].PositionY - enemies[i].PositionY) * (enemies[j].PositionY - enemies[i].PositionY) + (enemies[j].PositionX - enemies[i].PositionX) * (enemies[j].PositionX - enemies[i].PositionX))
                    {
                        enemies[j].zmiz(mriz);
                        enemies.Remove(enemies[j]);
                    }

                }
              //  if (enemies[i].PositionX <= arena.Margin.Left-15 || enemies[i].PositionY<=arena.Margin.Top - 15 || enemies[i].PositionX <= arena.Margin.Left + arena.Width - 15 || enemies[i].PositionY <= arena.Margin.Top + arena.Height - 15)
               

            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up:
                    up = -playerSpeed;
                    break;
                case Key.Down:
                    up = playerSpeed;
                    break;
                case Key.Left:
                    left = -playerSpeed;
                    break;
                case Key.Right:
                    left = playerSpeed;
                    break;
            }
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up:
                    up = 0;
                    break;
                case Key.Down:
                    up = 0;
                    break;
                case Key.Left:
                    left = 0;
                    break;
                case Key.Right:
                    left = 0;
                    break;
            }
        }
    }
}