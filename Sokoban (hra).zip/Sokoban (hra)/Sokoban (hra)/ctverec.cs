﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shapes;

namespace Sokoban__hra_
{
    internal class ctverec 
    {
        protected Rectangle q;
        public ctverec() 
        { 
            q = new Rectangle();
            q.Width = 30;
            q.Height = 30;
            q.VerticalAlignment = VerticalAlignment.Top;
            q.HorizontalAlignment = HorizontalAlignment.Left;
        }    
    }
}
