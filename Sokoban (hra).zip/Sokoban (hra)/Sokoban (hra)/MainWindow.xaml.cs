﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Sokoban__hra_
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public static bool reset = false;
        hra sokoban;
        hrac hraac;
        DispatcherTimer casovac = new DispatcherTimer(DispatcherPriority.Render);

        public MainWindow()
        {
            InitializeComponent();
            sokoban = new hra(mriz);
            hraac = new hrac(mriz);
            mriz.Children.Add(tlacitko);
            casovac.Interval = new TimeSpan(0, 0, 0, 0, 10);
            casovac.Tick += casvoacTick;
            casovac.Start();
        }

        private void casvoacTick(object sender, EventArgs e)
        {
            if(reset)
            {
                sokoban.odstranit();
                hraac.odstranit();
                sokoban = null;
                hraac = null;
                sokoban = new hra(mriz);
                hraac = new hrac(mriz);
                reset = false;
                mriz.Children.Add(tlacitko);
            }
        }

        private void klavesa(object sender, KeyEventArgs e) 
        {
            switch (e.Key)                      //pohyb hráče
            {
                case Key.Left:
                    hraac.pohniSe(-30, 0);
                    break;
                case Key.Right:
                    hraac.pohniSe(30, 0);
                    break;
                case Key.Up:
                    hraac.pohniSe(0, -30);
                    break;
                case Key.Down:
                    hraac.pohniSe(0, 30);
                    break;

            }
        }

        private void tlacitko_Click(object sender, RoutedEventArgs e)
        {
            sokoban.odstranit();
            hraac.odstranit();
            sokoban = null;
            hraac = null;
            hra.uroven = 1;
            sokoban = new hra(mriz);
            hraac = new hrac(mriz);
            mriz.Children.Add(tlacitko);                                            // v classe hra se vymaze mriz, proto se prida tlacitko znovu
        }
    }
    class hra
    {
        public static int uroven = 1;
        int urovenmax = 3;
        public static int[,] mapa;

        int[,] lvl = new int[,] {      //vytvoření mapy
            { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 },
            { 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1 },
            { 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1 },
            { 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1 },
            { 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1 },
            { 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1 },
            { 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1 },
            { 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1 },
            { 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1 },
            { 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1 },
            { 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 3, 1, 2, 0, 1 },
            { 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1 },
            { 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
        };

        int[,] lvl2 = new int[,] {      //vytvoření druhé mapy
            { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 },
            { 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1 },
            { 1, 0, 0, 1, 0, 0, 0, 3, 1, 0, 1, 1, 0, 1, 1, 1 },
            { 1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1 },
            { 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1 },
            { 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1 },
            { 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 1 },
            { 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1 },
            { 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1 },
            { 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1 },
            { 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1 },
            { 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1 },
            { 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 2, 0, 0, 1 },
            { 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 1 },
            { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
        };

        int[,] lvl3 = new int[,] {      //vytvoření třetí mapy
            { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 },
            { 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1 },
            { 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1 },
            { 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1 },
            { 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1 },
            { 1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1 },
            { 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1 },
            { 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1 },
            { 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 2, 0, 1 },
            { 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1 },
            { 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 3, 1, 0, 0, 1 },
            { 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0, 1 },
            { 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1 },
            { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }
        };




        static public konec cil;
        static public stena_ stena;
        static public kostka_ kostka;
        Grid MRIZG;

        public hra(Grid MRIZ)
        {
            MRIZG = MRIZ;
            MRIZ.Background = new SolidColorBrush(Colors.SandyBrown);
            generuj(MRIZ);
        }


        public void generuj(Grid MRIZ)
        {
            MRIZ.Children.Clear();
            if (uroven > urovenmax)  //po dokončenní všech levelů
            {

                var mainWindow = (Application.Current.MainWindow as MainWindow);  //zavře mainwindow
                if (mainWindow != null)
                {
                    mainWindow.Close();
                }
                MessageBox.Show("Gratuluji, vyhrál jsi");


            }
            else if (uroven == 1)   //přepínání na další level 
            {
                mapa = lvl;
            }
            else if (uroven == 2)
            {
                mapa = lvl2;
                MessageBox.Show("Dokončil jsi 1. level");
            }
            else if (uroven == 3)
            {
                mapa = lvl3;
                MessageBox.Show("Dokončil jsi 2. level");
            }




            for (int y = 0; y < 17; y++)
            {
                for (int x = 0; x < 16; x++)
                {

                    switch (mapa[y, x])
                    {
                        case 1:
                            stena = new stena_(MRIZ, x, y);
                            break;
                        case 2:
                            kostka = new kostka_(MRIZ, x, y);
                            break;
                        case 3:
                            cil = new konec(MRIZ, x, y);
                            break;
                        default:
                            break;
                    }
                }
            }
        }


        public void odstranit()  //odsraní stavajicí mapu
        {
            MRIZG.Children.Clear();
            mapa = null;
        }

    }

    class stena_ : ctverec
    {
        Rectangle b;
        public stena_(Grid MRIZ, int x, int y)
        {
            b = q;
            b.Margin = new Thickness(x * 30, y * 30, 0, 0);
            MRIZ.Children.Add(b);
            b.Fill = new SolidColorBrush(Colors.SaddleBrown);
        }

        public void odstranit()
        {
            b = null;
        }
    }

    class konec
    {
        Rectangle f;
        Grid MRIZG;
        public konec(Grid MRIZ, int x, int y)
        {
            MRIZG = MRIZ;
            f = new Rectangle();
            f.Width = 30;
            f.Height = 30;
            f.VerticalAlignment = VerticalAlignment.Top;
            f.HorizontalAlignment = HorizontalAlignment.Left;
            f.Margin = new Thickness(x * 30, y * 30, 0, 0);
            MRIZ.Children.Add(f);
            f.Fill = new SolidColorBrush(Colors.Black);
        }

        public void odstranit()
        {
            MRIZG.Children.Remove(f);
            f = null;
        }

    }



    class kostka_
    {
        Rectangle c;
        Grid MRIZG;
        public kostka_(Grid MRIZ, int x, int y)
        {
            MRIZG = MRIZ;
            c = new Rectangle();
            c.Width = 30;
            c.Height = 30;
            c.VerticalAlignment = VerticalAlignment.Top;
            c.HorizontalAlignment = HorizontalAlignment.Left;
            c.Margin = new Thickness(x * 30, y * 30, 0, 0);
            MRIZ.Children.Add(c);
            c.Fill = new SolidColorBrush(Colors.Blue);
        }

        public void odstranit()
        {
            MRIZG.Children.Remove(c);
            c = null;
        }

        public void pohyb(int x, int y)
        {
            int xx = Convert.ToInt32(c.Margin.Left) / 30;
            int yy = Convert.ToInt32(c.Margin.Top) / 30;

            bool jeNad;
            bool jePod;
            bool jeVlevo;
            bool jeVpravo;

            int zleva;
            int shora;


            if (hra.mapa[yy - 1, xx] == 9) { jeNad = true; } else { jeNad = false; }
            if (hra.mapa[yy + 1, xx] == 9) { jePod = true; } else { jePod = false; }
            if (hra.mapa[yy, xx - 1] == 9) { jeVlevo = true; } else { jeVlevo = false; }
            if (hra.mapa[yy, xx + 1] == 9) { jeVpravo = true; } else { jeVpravo = false; }

            if (hra.mapa[yy + (y / 30), xx + (x / 30)] == 3)
            {
                hra.uroven++;
                MainWindow.reset = true;
            }

            if (jeNad) //posouvání bloku dolů 
            {
                if (hra.mapa[yy + 1, xx] != 1)
                {
                    zleva = Convert.ToInt32(c.Margin.Left);
                    shora = Convert.ToInt32(c.Margin.Top);
                    hra.mapa[shora / 30, zleva / 30] = 0;
                    c.Margin = new Thickness(zleva, shora + 30, 0, 0);
                    hra.mapa[shora / 30 + 1, zleva / 30] = 2;
                    jeNad = false;
                    jePod = false;
                    jeVlevo = false;
                    jeVpravo = false;
                }
            }

            if (jePod) //posouvání bloku nahorů
            {
                if (hra.mapa[yy - 1, xx] != 1)
                {
                    zleva = Convert.ToInt32(c.Margin.Left);
                    shora = Convert.ToInt32(c.Margin.Top);
                    hra.mapa[shora / 30, zleva / 30] = 0;
                    c.Margin = new Thickness(zleva, shora - 30, 0, 0);
                    hra.mapa[shora / 30 - 1, zleva / 30] = 2;
                    jeNad = false;
                    jePod = false;
                    jeVlevo = false;
                    jeVpravo = false;
                }

            }

            if (jeVlevo) //posouvání bloku do prava 
            {
                if (hra.mapa[yy, xx + 1] != 1)
                {
                    zleva = Convert.ToInt32(c.Margin.Left);
                    shora = Convert.ToInt32(c.Margin.Top);
                    hra.mapa[shora / 30, zleva / 30] = 0;
                    c.Margin = new Thickness(zleva + 30, shora, 0, 0);
                    hra.mapa[shora / 30, zleva / 30 + 1] = 2;
                    jeNad = false;
                    jePod = false;
                    jeVlevo = false;
                    jeVpravo = false;
                }

            }

            if (jeVpravo) //posouvání bloku do leva 
            {
                if (hra.mapa[yy, xx - 1] != 1)
                {
                    zleva = Convert.ToInt32(c.Margin.Left);
                    shora = Convert.ToInt32(c.Margin.Top);
                    hra.mapa[shora / 30, zleva / 30] = 0;
                    c.Margin = new Thickness(zleva - 30, shora, 0, 0);
                    hra.mapa[shora / 30, zleva / 30 - 1] = 2;
                    jeNad = false;
                    jePod = false;
                    jeVlevo = false;
                    jeVpravo = false;
                }
            }
        }
    }

    class hrac
    {
        Rectangle k;
        Grid MRIZG;
        public hrac(Grid MRIZ)
        {
            MRIZG = MRIZ;
            k = new Rectangle();
            k.Width = 30;
            k.Height = 30;
            k.VerticalAlignment = VerticalAlignment.Top;
            k.HorizontalAlignment = HorizontalAlignment.Left;
            k.Margin = new Thickness(420, 390, 0, 0);
            MRIZ.Children.Add(k);
            k.Fill = new SolidColorBrush(Colors.HotPink);
        }

        public void odstranit()
        {
            MRIZG.Children.Remove(k);
            k = null;
        }

        internal void pohniSe(int x, int y)  //podmínka pro posouvání kostky
        {
            int xx = Convert.ToInt32(k.Margin.Left) / 30;
            int yy = Convert.ToInt32(k.Margin.Top) / 30;
             int l = y / 30;
            int m = x / 30;
            if (hra.mapa[yy + l, xx + m] != 2 && hra.mapa[yy + l, xx + m] != 1)
            {
                
                 hra.mapa[yy, xx] = 0;
                 k.Margin = new Thickness(k.Margin.Left + x, k.Margin.Top + y, 0, 0);
                 hra.mapa[yy + l, xx + m] = 9;
                
            }
            else if (hra.mapa[yy + l, xx + m] == 2 && hra.mapa[yy + l + l, xx + m + m] != 1
                && hra.mapa[yy + l + l, xx + m + m] != 2)
                 {
                    hra.kostka.pohyb(x, y);
                    hra.mapa[yy, xx] = 0;
                    k.Margin = new Thickness(k.Margin.Left + x, k.Margin.Top + y, 0, 0);
                    hra.mapa[yy + l, xx + m] = 9;
                 }
        }
    }
}

